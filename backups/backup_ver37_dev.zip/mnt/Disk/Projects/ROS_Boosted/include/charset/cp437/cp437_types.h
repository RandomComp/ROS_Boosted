#ifndef _RANDOM_OS_CP437_TYPES_H
#define _RANDOM_OS_CP437_TYPES_H

#include "core/basic_types.h"

typedef enum CP437_Code {
	CP437_NULL,					// \0
	CP437_SMILE,
	CP437_SMILE_2,
	CP437_CARDIOID,
	CP437_DIAMOND,
	CP437_CLUB_SUIT,
	CP437_SPADE_SUIT,
	CP437_CENTER_DOT,
	CP437_BACKSPACE,
	CP437_TAB,
	CP437_NEW_LINE,
	CP437_MALE_SIGN,
	CP437_FEMALE_SIGN,
	CP437_CARRIAGE_RETURN,
	CP437_DOUBLE_NOTE,
	CP437_SUN,
	CP437_TRIANGLE_RIGHT,
	CP437_TRIANGLE_LEFT,
	CP437_ARROW_UP_DOWN,
	CP437_DOUBLE_EXCLAMATION_MARK,
	CP437_PILCROW,
	CP437_SECTION_SIGN,
	CP437_BOLD_DASH,
	CP437_ARROW_UP_DOWN_UNDERLINED,
	CP437_ARROW_UP,
	CP437_ARROW_DOWN,
	CP437_ARROW_RIGHT,
	CP437_ARROW_LEFT,
	CP437_LEFT_BOTTOM_CORNER,
	CP437_ARROW_LEFT_RIGHT,
	CP437_TRIANGLE_UP,
	CP437_TRIANGLE_DOWN,
	CP437_SPACE,			  	// SPACE
	CP437_EXCLAMATION_MARK,   	// !
	CP437_DOUBLE_QUOTES,		// "
	CP437_NUMBER_SIGN,			// #
	CP437_DOLLAR_SIGN,			// $
	CP437_PERCENT_SIGN,			// %
	CP437_AMPERSAND,			// &
	CP437_QUOTE,				// '
	CP437_LEFT_PAREN,			// (
	CP437_RIGHT_PAREN,			// )
	CP437_ASTERISK,		   		// *
	CP437_PLUS_SIGN,			// +
	CP437_COMMA,				// ,
	CP437_MINUS_SIGN,			// -
	CP437_DOT,					// .
	CP437_SLASH,				// /
	CP437_0,					// 0
	CP437_1,					// 1
	CP437_2,					// 2
	CP437_3,					// 3
	CP437_4,					// 4
	CP437_5,					// 5
	CP437_6,					// 6
	CP437_7,					// 7
	CP437_8,					// 8
	CP437_9,					// 9
	CP437_COLON,				// :
	CP437_SEMICOLON,			// ;
	CP437_LESS_SIGN,			// <
	CP437_EQUAL,				// =
	CP437_BIG_SIGN,				// >
	CP437_QUESTION_MARK,		// ?
	CP437_AT_SIGN,				// @
	CP437_BIG_A,				// A
	CP437_BIG_B,				// B
	CP437_BIG_C,				// C
	CP437_BIG_D,				// D
	CP437_BIG_E,				// E
	CP437_BIG_F,				// F
	CP437_BIG_G,				// G
	CP437_BIG_H,				// H
	CP437_BIG_I,				// I
	CP437_BIG_J,				// J
	CP437_BIG_K,				// K
	CP437_BIG_L,				// L
	CP437_BIG_M,				// M
	CP437_BIG_N,				// N
	CP437_BIG_O,				// O
	CP437_BIG_P,				// P
	CP437_BIG_Q,				// Q
	CP437_BIG_R,				// R
	CP437_BIG_S,				// S
	CP437_BIG_T,				// T
	CP437_BIG_U,				// U
	CP437_BIG_V,				// V
	CP437_BIG_W,				// W
	CP437_BIG_X,				// X
	CP437_BIG_Y,				// Y
	CP437_BIG_Z,				// Z
	CP437_LEFT_BRACKET,			// [
	CP437_BACKSLASH,			/* \ */
	CP437_RIGHT_BRACKET,		// ]
	CP437_CIRCUMFLEX,			// ^
	CP437_UNDERLINE,			// _
	CP437_BACK_QUOTE,			// `
	CP437_A,					// a
	CP437_B,					// b
	CP437_C,					// c
	CP437_D,					// d
	CP437_E,					// e
	CP437_F,					// f
	CP437_G,					// g
	CP437_H,					// h
	CP437_I,					// i
	CP437_J,					// j
	CP437_K,					// k
	CP437_L,					// l
	CP437_M,					// m
	CP437_N,					// n
	CP437_O,					// o
	CP437_P,					// p
	CP437_Q,					// q
	CP437_R,					// r
	CP437_S,					// s
	CP437_T,					// t
	CP437_U,					// u
	CP437_V,					// v
	CP437_W,					// w
	CP437_X,					// x
	CP437_Y,					// y
	CP437_Z,					// z
	CP437_LEFT_BRACE,			// {
	CP437_VERTICAL_LINE,		// |
	CP437_RIGHT_BRACE,			// }
	CP437_TILDE,				// ~
} CP437_Code;

#endif