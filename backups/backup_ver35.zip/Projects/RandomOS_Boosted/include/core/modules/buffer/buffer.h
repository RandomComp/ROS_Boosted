#ifndef _RANDOM_OS_BUFFER_H
#define _RANDOM_OS_BUFFER_H

#include "core/basic_types.h"

#include "buffer/buffer_fwd.h"

bool Buffer_isValid(Buffer* buffer);

const c_str Buffer_whyIsInvalid(Buffer* buffer);

Buffer* Buffer_new(size_t size, size_t context_size, Buffer_CreationFlags flags);

#endif