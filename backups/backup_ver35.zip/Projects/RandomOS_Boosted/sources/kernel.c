#include "drivers/multiboot/multiboot_types.h"

#include "std/std.h"

#include "drivers/hid/keyboardps2.h"

#include "drivers/acpi/acpi.h"

#include "drivers/memory/ram.h"

void main(uint32 magic, multibootInfo* info) {
	RAM_init(info); // 4 MB

	STD_Init();

	printf("RAM Size is: [value: size]", RAM_getSize());

	KeyboardPS2_Init();

	ACPI_Init();

	kprintf("OS is booted succesfully!\n");

	clear(0);

	for (;;);
}