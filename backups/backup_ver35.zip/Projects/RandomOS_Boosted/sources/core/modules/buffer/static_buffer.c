#include "buffer/static_buffer.h"

#include "buffer/buffer.h"

#include "buffer/buffer_types.h"

#include "std/std.h"

Buffer* StaticBuffer_new(byte* ptr, size_t size) {
	if (ptr == nullptr) {
		klog(LOG_SEVERITY_ERROR, "Static buffer creation failure: requested ptr is nullptr\n");

		return nullptr;
	}

	Buffer* buffer = Buffer_new(true, size);

	if (buffer == nullptr) {
		klog(LOG_SEVERITY_ERROR, "Static buffer creation failure: Buffer_new returned nullptr (out of memory)\n");

		return nullptr;
	}

	buffer->data = ptr;
	buffer->data_size = size;
	buffer->have_data = true;
	buffer->is_static = true;

	return buffer;
}