#include "buffer/buffer.h"

#include "core/basic_types.h"

#include "buffer/buffer_types.h"

#include "drivers/memory/ram.h"

#include "builtins/mem.h"

#include "std/std.h"

#include "tasks/async/asyncio.h"

#include "math/bit_math.h"

#include "time/time.h"

bool Buffer_isValid(Buffer* buffer) {
	if (buffer == nullptr) return false;

	if (buffer->open ==  		nullptr ||
		buffer->seek ==  		nullptr ||
		buffer->write == 		nullptr ||
		buffer->read ==  		nullptr ||
		buffer->write_byte == 	nullptr ||
		buffer->read_byte == 	nullptr ||
		buffer->flush == 		nullptr ||
		buffer->fetch == 		nullptr ||
		buffer->close == 		nullptr
	) return false;

	if (buffer->data_size <= 0 || 
		buffer->data == nullptr) return false;

	if (buffer->have_context) {
		if (buffer->context_size <= 0 || 
			buffer->context == nullptr) return false;
	}

	return true;
}

const c_str Buffer_whyIsInvalid(Buffer* buffer) {
	if (buffer == nullptr) return "Invalid buffer pointer";

	if (buffer->open ==  		nullptr ||
		(buffer->have_seek && 
		buffer->seek ==  		nullptr) ||
		buffer->write == 		nullptr ||
		buffer->read ==  		nullptr ||
		buffer->write_byte == 	nullptr ||
		buffer->read_byte == 	nullptr ||
		buffer->flush == 		nullptr ||
		buffer->fetch == 		nullptr ||
		buffer->fetch_count == 	nullptr ||
		buffer->close == 		nullptr ||
		buffer->free == 		nullptr
	) return "Incomplete implementation of buffer methods (like open, write, flush, etc)";

	if (buffer->data_size <= 0 || 
			buffer->data == nullptr) return "Pointer to data is missing, or data size is 0.";

	if (buffer->have_context) {
		if (buffer->context_size <= 0 || 
			buffer->context == nullptr) return "The expected pointer to context data is missing, or context data size is 0.";
	}

	return "OK";
}

bool Buffer_checkForValidBuffer(Buffer* buffer) {
	if (!Buffer_isValid(buffer)) {
		klog(LOG_SEVERITY_ERROR, "Buffer operation failure: buffer invalid.\n");

		klog(LOG_SEVERITY_ERROR, 
			"Buffer is invalid because: [value: c_str]\n", Buffer_whyIsInvalid(buffer));

		return false;
	}

	return true;
}

static ErrorCode Buffer_sendID(Buffer* this) {
	if (!Buffer_checkForValidBuffer(this) || this->id == 0) {
		klog(LOG_SEVERITY_ERROR, "Buffer send id failure: buffer invalid or id is 0");

		return CODE_FAIL;
	}

	ErrorCode code = this->write_byte(this, BUFFER_MESS_BEGIN);

	if (code == CODE_FAIL) {
		klog(LOG_SEVERITY_ERROR, "Buffer send id failure: buffer->write_byte for BUFFER_MESS_BEGIN returned CODE_FAIL");

		return CODE_FAIL;
	}

	code = this->write_byte(this, sizeof(this->id));

	if (code == CODE_FAIL) {
		klog(LOG_SEVERITY_ERROR, "Buffer send id failure: buffer->write_byte for sizeof(buffer->id) returned CODE_FAIL");

		return CODE_FAIL;
	}

	code = this->write_byte(this, BUFFER_MESS_SIZE_END);

	if (code == CODE_FAIL) {
		klog(LOG_SEVERITY_ERROR, "Buffer send id failure: buffer->write_byte for BUFFER_MESS_SIZE_END returned CODE_FAIL");

		return CODE_FAIL;
	}

	for (size_t i = 0; i < sizeof(this->id); i++) {
		code = this->write_byte(this, GET_BYTE(this->id, i));

		if (code == CODE_FAIL) {
			klog(LOG_SEVERITY_ERROR, "Buffer send id failure: buffer->write_byte for id bytes returned CODE_FAIL");

			return CODE_FAIL;
		}
	}

	return CODE_OK;
}

ErrorCode Buffer_open(Buffer* this) {
	if (!Buffer_checkForValidBuffer(this))
		return CODE_FAIL;

	this->write_byte(this, BUFFER_OPEN);

	Buffer_sendID(this);

	this->flush(this, 0);

	// TODO: Сделать проверку на исключения со стороны цели

	this->is_open = true;

	return CODE_OK;
}

ErrorCode Buffer_seek(Buffer* this, ssize_t bytes, Buffer_FlagsSeek flag) {
	if (!Buffer_checkForValidBuffer(this))
		return CODE_FAIL;

	if (flag == BUFFER_FLAG_SEEK_BEGIN)
		this->pos = bytes;
	
	else if (flag == BUFFER_FLAG_SEEK_POS)
		this->pos += bytes;
	
	else if (flag == BUFFER_FLAG_SEEK_END)
		this->pos = this->data_size - bytes - 1;
}

ErrorCode Buffer_write(Buffer* this, size_t start, 
				  		size_t end, const byte* data, size_t bytes) {
	if (!Buffer_checkForValidBuffer(this))
		return CODE_FAIL;

	
}

ErrorCode Buffer_read(Buffer* this, size_t start, 
						size_t end, byte* data, size_t bytes) {
	if (!Buffer_checkForValidBuffer(this))
		return CODE_FAIL;

	
}

ErrorCode Buffer_write_byte(Buffer* this, byte data) {
	if (!Buffer_checkForValidBuffer(this))
		return CODE_FAIL;

	if (this->pos >= this->data_size) {
		if (!this->is_static) {
			this->data_size = this->pos;
			
			byte* new_data = realloc(this->data, this->data_size);

			if (new_data == nullptr) {
				klog(LOG_SEVERITY_ERROR, "Buffer write byte failure: pos is further than "
					"data_size, but realloc for increasing data size return "
					"nullptr (out of memory), forced flush call");
			}

			else this->data = new_data;
		}

		else {
			klog(LOG_SEVERITY_WARNING, "Buffer write byte warning: pos is further than "
				"data_size, but buffer is static, forced flush call");
		}
			
		this->flush(this, this->updated_bytes);
	}

	while (this->pos < 0) {
		this->pos += this->data_size;
	}

	this->data[this->pos] = data;

	this->pos++;

	this->updated_bytes++;

	return CODE_OK;
}

ErrorCode Buffer_read_byte(Buffer* this, byte* data) {
	if (!Buffer_checkForValidBuffer(this))
		return CODE_FAIL;

	if (this->pos >= this->data_size) {
		klog(LOG_SEVERITY_ERROR, "Buffer read byte failure: pos is further than data_size");
		
		return CODE_FAIL;
	}

	while (this->pos < 0) {
		this->pos += this->data_size;
	}

	*data = this->data[this->pos];

	this->pos++;

	return CODE_OK;
}

ErrorCode Buffer_flush(Buffer* this, size_t bytes) {
	if (!Buffer_checkForValidBuffer(this))
		return CODE_FAIL;

	if (bytes == 0)
		bytes = this->data_size;

	// TODO: Реализовать разбор комманд
}

ErrorCode Buffer_fetch(Buffer* this, size_t bytes) {
	if (!Buffer_checkForValidBuffer(this)) {
		klog(LOG_SEVERITY_ERROR, "Buffer fetch failure: buffer invalid");

		return CODE_FAIL;
	}

	if (bytes == 0) {
		ErrorCode code = this->fetch_count(this, &bytes);

		if (code == CODE_FAIL) {
			klog(LOG_SEVERITY_ERROR, "Buffer fetch failure: buffer->fetch_count returned CODE_FAIL");
			
			return CODE_FAIL;
		}
	}

	// TODO: Тут возвращать ответ
}

ErrorCode Buffer_fetch_count(Buffer* this) {
	if (!Buffer_checkForValidBuffer(this)) {
		klog(LOG_SEVERITY_ERROR, "Buffer fetch bytes count failure: buffer invalid");

		return CODE_FAIL;
	}

	// TODO: Тут возвращать размер ответа в байтах
}

ErrorCode Buffer_close(Buffer* this) {
	if (!Buffer_checkForValidBuffer(this)) {
		klog(LOG_SEVERITY_ERROR, "Buffer close failure: buffer invalid");

		return CODE_FAIL;
	}

	this->write_byte(this, BUFFER_CLOSE);

	this->flush(this, 0);

	// TODO: Сделать проверку на ошибки со стороны собеседника

	this->is_open = false;

	return CODE_OK;
}

static ErrorCode byteAwaiter(Awaiter* this) {
	if (!AsyncIO_isAwaiterActive(this)) {
		klog(LOG_SEVERITY_CRITICAL, "Buffer byte awaiter failure: awaiter is not active or invalid");

		return CODE_FAIL;
	}
	
	Buffer* buffer = AsyncIO_getArgs(this);

	if (!Buffer_checkForValidBuffer(buffer)) {
		klog(LOG_SEVERITY_ERROR, "Buffer byte awaiter failure: buffer invalid");

		return CODE_FAIL;
	}
	
	size_t byte_count = 0;

	ErrorCode code = buffer->fetch_count(buffer, &byte_count);

	if (code == CODE_FAIL) {
		klog(LOG_SEVERITY_ERROR, "Buffer byte awaiter failure: buffer->fetch_count returned CODE_FAIL");

		return CODE_FAIL;
	}

	if (byte_count > 0) {
		code = AsyncIO_return(this, nullptr);

		if (code == CODE_FAIL) {
			klog(LOG_SEVERITY_ERROR, "Buffer byte awaiter failure: AsyncIO_return returned CODE_FAIL");

			return CODE_FAIL;
		}
	}
	
	return CODE_OK;
}

static ErrorCode awaitForBytes(Buffer* this) {
	Awaiter* awaiter = AsyncIO_newAwaiter(byteAwaiter);

	if (awaiter == nullptr) {
		klog(LOG_SEVERITY_CRITICAL, "Buffer byte awaiter failure: AsyncIO_newAwaiter returned nullptr");

		return CODE_FAIL;
	}

	ErrorCode code = AsyncIO_setArgs(awaiter, this);

	if (code == CODE_FAIL) {
		AsyncIO_free(awaiter);

		klog(LOG_SEVERITY_ERROR, "Buffer byte awaiter failure: AsyncIO_setArgs returned CODE_FAIL");

		return CODE_FAIL;
	}

	code = AsyncIO_await(awaiter);

	if (code == CODE_FAIL) {
		AsyncIO_free(awaiter);

		klog(LOG_SEVERITY_ERROR, "Buffer byte awaiter failure: AsyncIO_await returned CODE_FAIL");

		return CODE_FAIL;
	}

	return CODE_OK;
}

static ErrorCode waitForBytes(Buffer* this) {
	if (!Buffer_checkForValidBuffer(this)) {
		klog(LOG_SEVERITY_CRITICAL, "Buffer byte waiter failure: buffer invalid");

		return CODE_FAIL;
	}
	
	size_t byte_count = 0;

	while (byte_count <= 0) {
		ErrorCode code = this->fetch_count(this, &byte_count);

		if (code == CODE_FAIL) {
			klog(LOG_SEVERITY_ERROR, "Buffer byte waiter failure: buffer->fetch_count returned CODE_FAIL");

			return CODE_FAIL;
		}
	}
	
	return CODE_OK;
}

ErrorCode Buffer_waitForBytes(Buffer* this) {
	if (!Buffer_checkForValidBuffer(this) || this->id == 0) {
		klog(LOG_SEVERITY_ERROR, "Buffer wait for bytes failure: buffer invalid or buffer has no id");

		return CODE_FAIL;
	}
	
	ErrorCode code = awaitForBytes(this);

	if (code == CODE_FAIL) {
		code = waitForBytes(this);

		if (code == CODE_FAIL) {
			klog(LOG_SEVERITY_ERROR, "Buffer wait for bytes failure: await failed and wait too");

			return CODE_FAIL;
		}
	}

	return CODE_OK;
}

ErrorCode Buffer_newID(Buffer* this) {
	if (!Buffer_checkForValidBuffer(this)) {
		klog(LOG_SEVERITY_ERROR, "Buffer new id failure: buffer invalid");

		return CODE_FAIL;
	}

	this->write_byte(this, BUFFER_NEW_ID);

	this->flush(this, 0);

	Buffer_waitForBytes(this);

	return CODE_OK;
}

void Buffer_free(Buffer* this) {
	if (!Buffer_checkForValidBuffer(this)) return;

	if (this->id != 0) {
		this->write_byte(this, BUFFER_FREE); // Освобождает ID

		// Отправка сообщения содержащий ID
		Buffer_sendID(this);

		this->flush(this, 0);
	}

	free(this->data);
	free(this->context);

	free(this);
}

Buffer* Buffer_new(size_t size, size_t context_size, Buffer_CreationFlags flags) {
	Buffer* buffer = malloc(sizeof(Buffer));

	if (buffer == nullptr) {
		klog(LOG_SEVERITY_ERROR, "Buffer creation failure: malloc for Buffer* buffer returned nullptr (out of memory)\n");

		return nullptr;
	}

	bool is_static = 	(flags & BUFFER_CREATION_IS_STATIC) != 0;
	bool have_context = (flags & BUFFER_CREATION_HAVE_CONTEXT) != 0;
	bool no_seek = 		(flags & BUFFER_CREATION_NO_SEEK) != 0;

	if (!is_static) {
		buffer->data = malloc(size);

		if (buffer->data == nullptr) {
			klog(LOG_SEVERITY_ERROR, "Buffer creation failure: malloc for buffer->data returned nullptr (out of memory)\n");

			free(buffer);

			return nullptr;
		}

		buffer->data_size = size;
	}

	buffer->updated_bytes = 0;

	buffer->context = nullptr;
	buffer->context_size = 0;
	buffer->have_context = false;

	buffer->is_open = false;
	buffer->is_static = is_static;

	buffer->id = 0;

	buffer->pos = 0;

	buffer->open = 			Buffer_open;
	buffer->seek = 			Buffer_seek;
	buffer->write = 		Buffer_write;
	buffer->read = 			Buffer_read;
	buffer->write_byte = 	Buffer_write_byte;
	buffer->read_byte = 	Buffer_read_byte;
	buffer->flush = 		Buffer_flush;
	buffer->fetch = 		Buffer_fetch;
	buffer->fetch_count = 	Buffer_fetch_count;
	buffer->close = 		Buffer_close;
	buffer->free = 			Buffer_free;

	buffer->have_seek = true;

	return buffer;
}