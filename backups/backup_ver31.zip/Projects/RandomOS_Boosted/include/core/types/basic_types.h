#ifndef _RANDOM_OS_TYPES_H
#define _RANDOM_OS_TYPES_H

#define true 1

#define false 0

#define far

#define PACKED __attribute__((packed))

#define INT8_MIN (int8)(0x80)

#define INT16_MIN (int16)(0x8000)

#define INT32_MIN (int32)(0x80000000)

#define INT64_MIN (int64)(0x8000000000000000)

#define UINT8_MIN (uint8)(0)

#define UINT16_MIN (uint16)(0)

#define UINT32_MIN (uint32)(0)

#define UINT64_MIN (uint64)(0)

#define INT8_MAX (int8)(0x7F)

#define INT16_MAX (int16)(0x7FFF)

#define INT32_MAX (int32)(0x7FFFFFFF)

#define INT64_MAX (int64)(0x7FFFFFFFFFFFFFFF)

#define UINT8_MAX (uint8)(0xFF)

#define UINT16_MAX (uint16)(0xFFFF)

#define UINT32_MAX (uint32)(0xFFFFFFFF)

#define UINT64_MAX (uint64)(0xFFFFFFFFFFFFFFFF)

#define FLOAT_MIN (double)(1.175494351e-38)

#define DOUBLE_MIN (double)(2.2250738585072014e-308)

#define FLOAT_MAX (double)(3.402823466e+38)

#define DOUBLE_MAX (double)(1.7976931348623158e+308)

#define FLT_EPSILON 1.192092896e-07f

#define FLT_MIN (FLOAT_MIN)

#define DBL_MIN (DOUBLE_MIN)

#define FLT_MAX (FLOAT_MAX)

#define DBL_MAX (DOUBLE_MAX)

#define MAX_FLOAT_STEPS 7

#define MAX_DOUBLE_STEPS 17

#define null 0

#define nullptr 0

#define DEBUG

//#define BITS_16

#define BITS_32

//#define BITS_64

// BITS_64 and BITS_16 is unsupported now.

#ifdef BITS_32
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned long uint32; // Unsupported for 16 BITS, use uint for this.
typedef unsigned long long uint64; // Unsupported for 16 BITS, use uint for this.

typedef signed char int8;
typedef signed short int16;
typedef signed long int32; // Unsupported for 16 BITS, use sint for this.
typedef signed long long int64; // Unsupported for 16 BITS, use sint for this.
#endif

typedef int8 sint8;
typedef int16 sint16;
typedef int32 sint32;
typedef int64 sint64;

typedef uint8 uint8_t;
typedef uint16 uint16_t;
typedef uint32 uint32_t;
typedef uint64 uint64_t;

typedef int8 int8_t;
typedef int16 int16_t;
typedef int32 int32_t;
typedef int64 int64_t;

typedef void* void_ptr;
typedef uint8_ptr byte_ptr;
typedef uint16_ptr word_ptr;
typedef uint32_ptr dword_ptr;
typedef uint64_ptr qword_ptr;

typedef uint8* uint8_ptr;
typedef uint16* uint16_ptr;
typedef uint32* uint32_ptr;
typedef uint64* uint64_ptr;

typedef int8* int8_ptr;
typedef int16* int16_ptr;
typedef int32* int32_ptr;
typedef int64* int64_ptr;

typedef uint32 size_t;

typedef int8 c_char;

typedef c_char* c_char_ptr;

typedef c_char_ptr c_str;

typedef c_str* c_str_ptr;

typedef uint8 bool;

typedef uint8 byte;
typedef uint16 word;
typedef uint32 dword;
typedef uint64 qword;

#define static_assert _Static_assert

#endif